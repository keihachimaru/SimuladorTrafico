package src.simulator.model;

public enum Weather {
	SUNNY, CLOUDY, RAINY, WINDY, STORM;
}
